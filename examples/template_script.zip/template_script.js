(function() {
	MathJax.Hub.Queue(['Typeset', MathJax.Hub]);
}());